using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Disintegrate : MonoBehaviour
{
   public float countdownTime = 2.0f;
    private bool isDisappearing = false;

    private void OnMouseDown()
    {
        if (!isDisappearing)
        {
            StartCoroutine(StartCountdown());
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Destroy(gameObject); // Destroy the tile when it collides with the player
        }
    }

    private IEnumerator StartCountdown()
    {
        isDisappearing = true;

        yield return new WaitForSeconds(countdownTime);

        // Deactivate the game object to make it disappear
        gameObject.SetActive(false);
    }
}

